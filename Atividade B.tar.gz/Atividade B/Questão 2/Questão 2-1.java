
public class Q2 {
	
	public static void main(String[] args){
		
		int sum = 0, number = 1;
		
		while (number <= 100){
			
			sum = sum + number;
			number = number +1;
			
			System.out.println(number);
		}
		
	}

}
