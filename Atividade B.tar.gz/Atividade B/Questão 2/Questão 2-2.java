
public class Q2_alter {

	public static void main(String[] args){
		
		int sum = 0, number = 1;
		
		while (sum <= 1000000){
			sum+=number;
			number++;
			
			System.out.println(sum);
		}
	}
	
}
