
public class Apartamento {
	
	int area;
	int n_quartos;
	String localização;
	String tipo;
	String proprietário;

}

public class Metodos{
	
	public static void main(String[] args){
		
		//Novo
		Apartamento a1 = new Apartamento();
		
		a1.area = 150;
		a1.n_quartos = 4;
		a1.localização = "15º Andar";
		a1.tipo = "Luxo";
		a1.proprietário = "Artur";
		
	}
	
}
