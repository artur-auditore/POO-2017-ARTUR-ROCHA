
class Veiculo {
	
	String nome;
	double preço;
	String montadora;
	int ano;
	
	void aumentapreço(double aumento){
		double novoPreço = preço + aumento;
		this.preço = novoPreço;
	}

}

public class AlgunsMetodos{
	
	public static void main(String[] args){
		
		//Novo veiculo
		Veiculo v1 = new Veiculo();
		
		//Alterar valores
		v1.nome = "Celta";
		v1.preço = 21000;
		v1.montadora = "Chevrollet";
		v1.ano = 2006;
		
		
	}
}
