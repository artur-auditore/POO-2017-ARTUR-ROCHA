
public class Funcionario {
	String nome;
	String cargo;
	double salario;
	

}
