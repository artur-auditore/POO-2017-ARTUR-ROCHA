
class Conta_Bancaria {
	
	String titular;
	double saldo;
	double limite;
	String tipo;
	
	void deposita(double valor){
		double novoSaldo = saldo + valor;
		this.saldo = novoSaldo;
	}
	
	

}

public class MetodosConta{
	
	public static void main(String[] args){
		
		//Nova Conta
		Conta_Bancaria c1 = new Conta_Bancaria();
		
		//Alterar valores
		c1.titular = "Artur";
		c1.saldo = 900;
		c1.limite = 2000;
		c1.tipo = "Poupança";
		
		//Deposita na conta
		c1.deposita(100);
	}
}